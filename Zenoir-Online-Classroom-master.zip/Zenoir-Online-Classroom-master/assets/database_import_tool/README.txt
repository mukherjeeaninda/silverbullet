You can use this tool to import user 
information such as username and password
into the zenoir database.
Just edit the conn.php file to match the 
zenoir database information and follow the
instructions in the page(con_form.php)