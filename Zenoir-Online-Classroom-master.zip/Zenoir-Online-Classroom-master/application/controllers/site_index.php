<?php
class site_index extends ci_Controller{
	
	function index(){
		echo "HOME PAGE";
	}
	
}
?>