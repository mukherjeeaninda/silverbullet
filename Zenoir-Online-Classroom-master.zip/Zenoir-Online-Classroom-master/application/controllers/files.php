<?php
class files extends ci_Controller{
	function create(){
		
		$this->files_model->create();
	}
}
?>