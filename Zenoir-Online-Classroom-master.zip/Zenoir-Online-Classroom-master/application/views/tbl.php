<?php
print_r($table);
?>