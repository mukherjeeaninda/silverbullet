<?php
$config = array(array('field'=>'email', 'label'=>'Email', 'rules'=>'trim|required|valid_email'));
?>